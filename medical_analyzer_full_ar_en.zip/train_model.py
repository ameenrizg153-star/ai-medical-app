import pandas as pd, os, joblib
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

CSV = 'Training.csv'
if not os.path.exists(CSV):
    print('Training.csv not found. Populate with labeled data to train.')
else:
    df = pd.read_csv(CSV)
    if 'diagnosis' not in df.columns:
        print('Training.csv must include diagnosis label column.')
    else:
        X = df.drop(columns=['diagnosis'])
        y = df['diagnosis']
        X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42)
        clf = DecisionTreeClassifier()
        clf.fit(X_train, y_train)
        preds = clf.predict(X_test)
        acc = (preds == y_test).mean()
        print('Trained model accuracy:', acc)
        joblib.dump(clf, 'medical_diagnosis_model.joblib')
        print('Saved model to medical_diagnosis_model.joblib')

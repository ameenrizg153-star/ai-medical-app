# Medical AI Analyzer - Full (AR/EN)

This package contains a bilingual Streamlit application to analyze lab test results locally.
Files included:
- app.py (Streamlit app)
- tests_database.csv (full tests DB)
- Training.csv (training template)
- train_model.py (train script)
- requirements.txt
- packages.txt
How to run:
1. python3 -m venv venv
2. source venv/bin/activate   # Windows: venv\Scripts\activate
3. pip install -r requirements.txt
4. (If using OCR) install system packages: sudo apt install -y poppler-utils tesseract-ocr tesseract-ocr-ara
5. streamlit run app.py

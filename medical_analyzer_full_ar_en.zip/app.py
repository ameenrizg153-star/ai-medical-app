import streamlit as st
import pandas as pd, os, re, io
from PIL import Image
import pytesseract, numpy as np, cv2

st.set_page_config(page_title='Medical AI Analyzer', layout='wide')

BASE_DIR = os.path.dirname(__file__)
TESTS_CSV = os.path.join(BASE_DIR, 'tests_database.csv')

@st.cache_data
def load_tests_db():
    return pd.read_csv(TESTS_CSV)

def preprocess_image(file_bytes):
    try:
        img = Image.open(io.BytesIO(file_bytes)).convert('RGB')
        arr = np.array(img)
        gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)
        blur = cv2.medianBlur(gray,3)
        thresh = cv2.adaptiveThreshold(blur,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,11,2)
        return Image.fromarray(thresh)
    except Exception:
        return Image.open(io.BytesIO(file_bytes))

def ocr_image(file_bytes):
    proc = preprocess_image(file_bytes)
    try:
        txt = pytesseract.image_to_string(proc, lang='eng+ara', config='--oem 3 --psm 6')
        return txt
    except Exception:
        return ''

def compare_and_advise(user_df, tests_db, lang='ar'):
    advices = []
    for idx, row in user_df.iterrows():
        code = str(row.get('Code') or row.get('code') or '').strip().lower()
        val = row.get('Result') or row.get('result') or row.get('value') or ''
        if code == '' or val == '': continue
        match = tests_db[tests_db['code'].str.lower() == code]
        if match.empty:
            msg = 'Test not found in database.' if lang=='en' else 'لم يتم العثور على الفحص في قاعدة البيانات.'
            advices.append({'code':code,'name':code,'value':val,'status':'Unknown','advice':msg})
            continue
        t = match.iloc[0]
        name = t['name_en'] if lang=='en' else t['name_ar']
        unit = t.get('unit','')
        advice = ''
        status = 'Normal' if lang=='en' else 'طبيعي'
        try:
            valf = float(val)
            low = float(t['low']) if not pd.isna(t['low']) else None
            high = float(t['high']) if not pd.isna(t['high']) else None
            if low is not None and valf < low:
                status = 'Low' if lang=='en' else 'منخفض'
                advice = t.get('recommendation_low','') or ''
            elif high is not None and valf > high:
                status = 'High' if lang=='en' else 'مرتفع'
                advice = t.get('recommendation_high','') or ''
            # Extra direct advice overrides for clarity
            if t['code'] == 'sodium' and status in ('High','مرتفع'):
                advice = 'High sodium — may indicate fluid imbalance or dehydration.' if lang=='en' else 'ارتفاع الصوديوم — قد يشير إلى خلل توازن السوائل أو جفاف.'
            if t['code'] == 'pus_cells' and status not in ('Normal','طبيعي'):
                advice = 'Pus cells in urine — suggestive of urinary tract infection.' if lang=='en' else 'وجود خلايا صديد في البول — قد يشير إلى التهاب في المسالك البولية.'
            if t['code'] == 'rbcs_urine' and status not in ('Normal','طبيعي'):
                advice = 'Blood in urine — needs follow-up (trauma, stones, infection).' if lang=='en' else 'وجود كريات دم حمراء في البول — يحتاج متابعة (إصابة، حصى، أو التهاب).'
            if t['code'] == 'creatinine' and status in ('High','مرتفع'):
                advice = 'High creatinine — may indicate reduced kidney function.' if lang=='en' else 'ارتفاع الكرياتينين — قد يدل على تراجع في وظائف الكلى.'
            if t['code'] == 'glucose_fasting' and status in ('High','مرتفع'):
                advice = 'High fasting glucose — consider diabetes screening.' if lang=='en' else 'ارتفاع سكر الصيام — قد يشير إلى مرض السكري أو مقدماته.'
        except Exception:
            status = 'Not comparable' if lang=='en' else 'غير قابل للمقارنة'
            advice = 'Value not numeric, please enter a valid number.' if lang=='en' else 'القيمة غير رقمية، يرجى إدخال قيمة صحيحة.'
        advices.append({'code':t['code'],'name':name,'value':val,'unit':unit,'status':status,'advice':advice})
    return advices

st.title('🩺 Medical AI Analyzer')
lang = st.sidebar.selectbox('Language / اللغة', ['Arabic - العربية','English - English'])
lang_code = 'ar' if 'Arabic' in lang else 'en'

tests_db = load_tests_db()

mode = st.sidebar.selectbox('Mode / الوضع', ['Upload CSV/XLSX results','Upload image/PDF (OCR)','Manual entry'])

if mode == 'Upload CSV/XLSX results':
    uploaded = st.file_uploader('Upload results file (CSV or XLSX) with columns: Code, Result
ارفع ملف النتائج (CSV أو XLSX) يحتوي عمودين: Code, Result', type=['csv','xlsx'])
    if uploaded:
        try:
            if uploaded.name.lower().endswith('.csv'):
                df = pd.read_csv(uploaded)
            else:
                df = pd.read_excel(uploaded)
            st.subheader('Uploaded file / الملف المرفوع')
            st.dataframe(df)
            advices = compare_and_advise(df, tests_db, lang= 'ar' if lang_code=='ar' else 'en')
            st.subheader('Analysis / نتائج التحليل')
            for a in advices:
                st.markdown(f"- **{a['name']}** — {a['value']} {a.get('unit','')} — **{a['status']}**")
                if a['advice']:
                    st.info(a['advice'])
        except Exception as e:
            st.error('Error reading file: ' + str(e))

elif mode == 'Upload image/PDF (OCR)':
    uploaded = st.file_uploader('Upload image or PDF report (OCR) / ارفع صورة أو PDF للتقرير (OCR)', type=['png','jpg','jpeg','pdf'])
    if uploaded:
        file_bytes = uploaded.read()
        text = ocr_image(file_bytes)
        st.subheader('Extracted text / النص المستخرج')
        st.text_area('', text, height=300)
        rows = []
        for _, t in tests_db.iterrows():
            code = str(t['code']).lower()
            aliases = str(t.get('aliases','')).lower().split(';') if pd.notna(t.get('aliases','')) else []
            keys = [code] + aliases + [str(t['name_en']).lower(), str(t['name_ar']).lower()]
            for k in keys:
                if not k: continue
                m = re.search(re.escape(k) + r'.{0,40}(\d+\.?\d*)', text.lower())
                if m:
                    rows.append({'Code':code,'Result':m.group(1)})
                    break
        if rows:
            df = pd.DataFrame(rows)
            st.subheader('Extracted values / القيم المستخرجة')
            st.dataframe(df)
            advices = compare_and_advise(df, tests_db, lang= 'ar' if lang_code=='ar' else 'en')
            st.subheader('Analysis / نتائج التحليل')
            for a in advices:
                st.markdown(f"- **{a['name']}** — {a['value']} {a.get('unit','')} — **{a['status']}**")
                if a['advice']:
                    st.info(a['advice'])
        else:
            st.warning('No understandable values found in text. Try clearer image or upload CSV. / لم يتم العثور على قيم مفهومة في النص. جرب صورة أوضح أو رفع CSV.')

else:
    st.subheader('Manual entry / إدخال يدوي')
    codes = tests_db['code'].tolist()
    code_sel = st.selectbox('Choose test / اختر الفحص', codes)
    val = st.text_input('Enter value (number) / أدخل القيمة (رقم)')
    if st.button('Analyze / تحليل'):
        df = pd.DataFrame([{'Code':code_sel,'Result':val}])
        advices = compare_and_advise(df, tests_db, lang= 'ar' if lang_code=='ar' else 'en')
        for a in advices:
            st.markdown(f"- **{a['name']}** — {a['value']} {a.get('unit','')} — **{a['status']}**")
            if a['advice']:
                st.info(a['advice'])
